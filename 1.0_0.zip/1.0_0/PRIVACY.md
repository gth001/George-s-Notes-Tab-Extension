# Extension Privacy Policy

This extension had never collected and will never collect any kind of data at all about its users, or send any data back to any central server.
